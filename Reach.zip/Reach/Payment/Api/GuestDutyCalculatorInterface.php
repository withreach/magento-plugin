<?php

namespace Reach\Payment\Api;

/**
 * @api
 */
interface GuestDutyCalculatorInterface extends DutyCalculatorInterface
{
  
}
